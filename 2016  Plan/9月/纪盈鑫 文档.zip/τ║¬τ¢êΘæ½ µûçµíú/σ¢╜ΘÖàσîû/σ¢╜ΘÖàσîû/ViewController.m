//
//  ViewController.m
//  国际化 i18n
// internationalization
// 
//  Created by tarena on 16/9/28.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    
    [self.view addSubview:label];
    
    label.text = NSLocalizedString(@"label", @"这是无意义的 可不加");
    
    UILabel *label1 = [[UILabel alloc]initWithFrame:CGRectMake(100, 200, 100, 100)];
    
    [self.view addSubview:label1];
    
    label1.text = NSLocalizedString(@"label1", @"这是无意义的 可不加");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
