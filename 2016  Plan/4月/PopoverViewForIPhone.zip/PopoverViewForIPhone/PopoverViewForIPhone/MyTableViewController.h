//
//  MyTableViewController.h
//  PopoverViewForIPhone
//
//  Created by Qinting on 16/7/29.
//  Copyright © 2016年 liuhj. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MyTableViewController;

@protocol MyTableViewControllerDelegate <NSObject>

-(void)myTableViewController:(MyTableViewController*)vc didClickAtIndex:(NSInteger)index;
@end

@interface MyTableViewController : UITableViewController
@property (nonatomic,weak) id<MyTableViewControllerDelegate>  delegate;
@end
