//
//  ViewController.m
//  PopoverViewForIPhone
//
//  Created by 海军 on 16/1/25.
//  Copyright © 2016年 liuhj. All rights reserved.
//

#import "ViewController.h"
#import "MyTableViewController.h"
@interface ViewController ()<UIPopoverPresentationControllerDelegate,MyTableViewControllerDelegate>

@property (nonatomic, strong) UIBarButtonItem *popoverButton;

@property (nonatomic, strong) NSMutableArray *dataList;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIBarButtonItem *popoverButton = [[UIBarButtonItem alloc]initWithTitle:@"Pop!" style:UIBarButtonItemStylePlain target:self action:@selector(presentPopover)];
    self.popoverButton = popoverButton;
    self.navigationItem.rightBarButtonItem = popoverButton;
    
}
- (void)presentPopover {
    
    MyTableViewController *popoverContentController = [[MyTableViewController alloc]init];
    popoverContentController.preferredContentSize = CGSizeMake(200, 300);
    popoverContentController.modalPresentationStyle = UIModalPresentationPopover;
//    设置代理 并实现代理方法
    popoverContentController.popoverPresentationController.delegate = self;
    popoverContentController.delegate = self;
    [self presentViewController:popoverContentController animated:YES completion:^{
        
    }];
    
}

#pragma mark - UIPopoverPresentationControllerDelegate
- (void)prepareForPopoverPresentation:(UIPopoverPresentationController *)popoverPresentationController {
    popoverPresentationController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    popoverPresentationController.barButtonItem = self.popoverButton;
}

//多种弹出的样式
- (UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController *)controller {
    return UIModalPresentationNone;
}

#pragma mark - 代理方法
-(void)myTableViewController:(MyTableViewController *)vc didClickAtIndex:(NSInteger)index{
    NSLog(@"选中:%ld行",index);
}

@end
